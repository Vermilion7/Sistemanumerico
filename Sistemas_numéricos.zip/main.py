def convertir_a_base_decimal(numero, base):
    digitos = "0123456789ABCDEF"
    numero = numero.upper()
    decimal = 0
    potencia = 0

    for i in range(len(numero) - 1, -1, -1):
        valor = digitos.index(numero[i])
        decimal += valor * (base ** potencia)
        potencia += 1

    return decimal

def convertir_de_base_decimal(numero, base):
    digitos = "0123456789ABCDEF"
    nuevo_numero = ""

    while numero > 0:
        residuo = numero % base
        nuevo_numero = digitos[residuo] + nuevo_numero
        numero //= base

    return nuevo_numero

def main():
    M = int(input("Ingrese la base M (entre 1 y 16): "))
    N = int(input("Ingrese la base N (entre 1 y 16): "))
    numero_en_base_M = input(f"Ingrese el número en base {M}: ")

    try:
        decimal = convertir_a_base_decimal(numero_en_base_M, M)
        numero_en_base_N = convertir_de_base_decimal(decimal, N)
        numero_binario = bin(decimal)[2:]
        valor_ascii = chr(decimal)
        
        print(f"Número en base {N}: {numero_en_base_N}")
        print("Representación binaria:", numero_binario)
        print("Valor ASCII:", valor_ascii)
    except ValueError:
        print("Número no válido")

if __name__ == "__main__":
    main()
